/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./pages/**/*.{js,jsx,ts,tsx}",
    "./components/**/*.{js,jsx,ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        choppies: {
          red: "#D32F2F",
          green: "#2E7D32",
          dark: "#1B5E20",
          light: "#FBEAEA"
        }
      },
          borderRadius: {
            xl: "1rem",
            '2xl': "1.25rem"
          },
          boxShadow: {
            soft: "0 10px 20px rgba(0,0,0,0.08)"
          }
    },
    fontFamily: {
      sans: ["ui-sans-serif", "system-ui", "Segoe UI", "Roboto", "Helvetica", "Arial", "Noto Sans", "sans-serif"]
    }
  },
  plugins: []
};
