import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useRouter } from 'next/router';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    // If already logged in, send them to their role dashboard
    const init = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        const { data } = await supabase.from('profiles').select('role').eq('id', session.user.id).single();
        if (data?.role) router.replace(`/${data.role}`);
      }
    };
    init();
  }, [router]);

  const onSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      setError(error.message);
      return;
    }
    const { data: profile } = await supabase.from('profiles').select('role').eq('id', data.user.id).single();
    if (profile?.role) router.push(`/${profile.role}`);
    else router.push('/');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-choppies-light">
      <form onSubmit={onSubmit} className="bg-white p-6 rounded-2xl shadow-soft w-full max-w-sm">
        <h1 className="text-xl font-semibold mb-4 text-choppies-red">Choppies Login</h1>
        {error && <p className="text-red-600 text-sm mb-2">{error}</p>}
        <label className="block text-sm mb-1">Email</label>
        <input
          type="email"
          className="w-full border rounded-xl px-3 py-2 mb-3"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="admin@choppies.com"
          required
        />
        <label className="block text-sm mb-1">Password</label>
        <input
          type="password"
          className="w-full border rounded-xl px-3 py-2 mb-4"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="••••••••"
          required
        />
        <button type="submit" className="w-full bg-choppies-green text-white rounded-xl py-2">
          Sign In
        </button>
        <p className="text-xs text-gray-500 mt-3">
          Demo: admin@choppies.com / Admin123!
        </p>
      </form>
    </div>
  );
}
