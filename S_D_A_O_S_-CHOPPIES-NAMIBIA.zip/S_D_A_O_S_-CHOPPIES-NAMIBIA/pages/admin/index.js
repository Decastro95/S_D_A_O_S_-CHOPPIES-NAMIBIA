import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { supabase } from '../../lib/supabaseClient';
import Layout from '../../components/Layout';

export default function AdminDashboard() {
  const router = useRouter();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const init = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return router.replace('/login');
      const { data, error } = await supabase.from('profiles').select('full_name, role').eq('id', session.user.id).single();
      if (error) return router.replace('/login');
      if (data.role !== 'admin') return router.replace(`/${data.role}`);
      setProfile(data);
      setLoading(false);
    };
    init();
  }, [router]);

  if (loading) return <div className="p-6">Loading...</div>;

  return (
    <Layout title="Admin Dashboard">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-choppies-light rounded-2xl p-4 border border-red-100">
          <h2 className="text-lg font-semibold mb-2">Shops Overview</h2>
          <p className="text-sm opacity-80">Configure shops, users, and policies.</p>
        </div>
        <div className="bg-white rounded-2xl p-4 border">
          <h2 className="text-lg font-semibold mb-2">Sales (All)</h2>
          <p className="text-sm opacity-80">Aggregate KPI widgets here.</p>
        </div>
        <div className="bg-white rounded-2xl p-4 border">
          <h2 className="text-lg font-semibold mb-2">Staff</h2>
          <p className="text-sm opacity-80">Invite staff & assign roles.</p>
        </div>
      </div>
    </Layout>
  );
}
