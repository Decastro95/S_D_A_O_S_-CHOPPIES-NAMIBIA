import Link from 'next/link';
import Image from 'next/image';
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { useRouter } from 'next/router';

export default function Layout({ children, title = 'Choppies Dashboard' }) {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const router = useRouter();

  useEffect(() => {
    const init = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setUser(session?.user ?? null);
      if (session?.user) {
        const { data, error } = await supabase
          .from('profiles')
          .select('full_name, role')
          .eq('id', session.user.id)
          .single();
        if (!error) setProfile(data);
      }
    };
    init();
  }, []);

  const signOut = async () => {
    await supabase.auth.signOut();
    router.push('/login');
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="fixed top-0 inset-x-0 h-16 bg-choppies-red text-white flex items-center px-4 shadow-soft z-40">
        <div className="flex items-center gap-3">
          <Image src="/logo-choppies.png" alt="Choppies" width={36} height={36} />
          <h1 className="font-semibold text-lg">{title}</h1>
        </div>
        <div className="ml-auto flex items-center gap-4">
          {profile?.full_name && <span className="text-sm opacity-90">{profile.full_name} ({profile.role})</span>}
          {user ? (
            <button onClick={signOut} className="bg-white/15 hover:bg-white/25 rounded-xl px-3 py-1 text-sm">
              Sign out
            </button>
          ) : (
            <Link href="/login" className="bg-white text-choppies-red rounded-xl px-3 py-1 text-sm">Login</Link>
          )}
        </div>
      </header>

      {/* Main */}
      <div className="pt-16 flex">
        {/* Sidebar */}
        <aside className="w-64 bg-choppies-green text-white min-h-[calc(100vh-4rem)] p-4">
          <nav className="space-y-1">
            <Link href="/admin" className="block px-3 py-2 rounded-xl hover:bg-white/10">Admin</Link>
            <Link href="/manager" className="block px-3 py-2 rounded-xl hover:bg-white/10">Manager</Link>
            <Link href="/cashier" className="block px-3 py-2 rounded-xl hover:bg-white/10">Cashier</Link>
          </nav>
        </aside>

        {/* Content */}
        <main className="flex-1 p-6">
          <div className="bg-white rounded-2xl shadow-soft p-6">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
