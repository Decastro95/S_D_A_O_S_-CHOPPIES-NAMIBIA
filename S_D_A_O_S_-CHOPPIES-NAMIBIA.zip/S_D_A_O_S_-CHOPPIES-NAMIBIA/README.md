# S_D_A_O_S_ – CHOPPIES NAMIBIA (Next.js + Tailwind + Supabase)

A starter with three role-based dashboards (**admin**, **manager**, **cashier**) sharing a common layout and corporate branding.

## 1) Quickstart

```bash
# 1. Install deps
npm i

# 2. Run dev
npm run dev
```

Create `.env.local` in the project root:

```
NEXT_PUBLIC_SUPABASE_URL=YOUR_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```

## 2) Tailwind

Already configured. Edit brand colors in `tailwind.config.js`.

## 3) Supabase Setup

1. Create a new Supabase project.
2. Open **SQL Editor** and paste/run `./sql/profiles.sql` using the **service_role** (or run as migration).
3. In **Authentication → Providers**, enable Email/Password.
4. In **Table Editor**, confirm you have a `profiles` table with `role` column (the SQL creates it).

### Seeded Accounts

- `admin@choppies.com / Admin123!` → `/admin`
- `manager@choppies.com / Manager123!` → `/manager`
- `cashier@choppies.com / Cashier123!` → `/cashier`

## 4) Deploy

- **CodeSandbox**: Import this ZIP or a GitHub repo, then make the sandbox public.
- **Vercel**: One‑click deploy from CodeSandbox or `vercel` CLI.

## 5) Notes

- Client pages verify role and redirect if needed.
- Layout: Red header, green sidebar, rounded cards.
- Replace placeholders with real metrics as you integrate data.
